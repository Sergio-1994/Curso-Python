from setuptools import setup

setup(
    name='paqueteCalculos',
    version='1.0',
    description='Paquete de redondeo y potencia',
    author='Sergio',
    author_email='sergiolopera.94@gmail.com',
    packages=["calculos","calculos.potenciaRedondeo"]
)