def potencia(base, exponente):
    print(f'El numero {base} elevado a {exponente} es igual a {base**exponente}')

def redondear(num):
    print(f'El numero redondeado es igual a {round(num)}')